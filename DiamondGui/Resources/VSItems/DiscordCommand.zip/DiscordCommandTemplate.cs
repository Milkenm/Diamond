﻿#region Usings
using System;
using System.Threading.Tasks;

using Discord.Commands;

using static DiamondGui.Functions;
#endregion Usings



namespace DiamondGui.Commands
{
	public class $itemname$ : ModuleBase<SocketCommandContext>
	{
		[Command("$itemname$"), Alias("$itemname$"), Summary("$itemname$")]
		public async Task CMD_$itemname$()
		{
			try
			{

			}
			catch (Exception _Exception)
			{
				ShowException(_Exception, "DiamondGui.Commands.$itemname$.CMD_$itemname$()");
			}
		}
	}
}